create function set_week_day() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.week_day := TRIM(UPPER(TO_CHAR(NEW.requested_datetime, 'Day')))::week_day;
    RETURN NEW;
END;
$$;

alter function set_week_day() owner to postgres;

grant execute on function set_week_day() to anon;

grant execute on function set_week_day() to authenticated;

grant execute on function set_week_day() to service_role;

