create function set_updated_at() returns trigger
    language plpgsql
as
$$
begin
    new.updated_at = now();   -- 修改时更新为当前时间
    return new;
end;
$$;

alter function set_updated_at() owner to postgres;

grant execute on function set_updated_at() to anon;

grant execute on function set_updated_at() to authenticated;

grant execute on function set_updated_at() to service_role;

