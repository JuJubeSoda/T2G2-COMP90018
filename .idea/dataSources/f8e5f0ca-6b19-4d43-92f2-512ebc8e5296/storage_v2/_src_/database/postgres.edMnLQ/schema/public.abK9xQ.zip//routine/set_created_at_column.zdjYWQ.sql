create function set_created_at_column() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.created_at IS NULL THEN
        NEW.created_at = NOW();
    END IF;
    RETURN NEW;
END;
$$;

alter function set_created_at_column() owner to postgres;

grant execute on function set_created_at_column() to anon;

grant execute on function set_created_at_column() to authenticated;

grant execute on function set_created_at_column() to service_role;

